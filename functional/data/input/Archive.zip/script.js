function changeConfigValues()
{
	blackberry.app.author = "Incorrect Author";
	blackberry.app.authorEmail = "incorrect@email.com";
	blackberry.app.authorURL = "Incorrect Author URL";
	blackberry.app.copyright = "Incorrect Copyright";
	blackberry.app.description = "Incorrect Description";
	blackberry.app.id = "incorrect id";
	blackberry.app.license = "Incorrect License";
	blackberry.app.licenseURL = "IncorrectLicenseUrl";
	blackberry.app.name = "Incorrect Name";
	blackberry.app.version = "9.9.9";
}